import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class ButtonFactory {

    public static JButton createNaviButton(String iconName, String tipText, ActionListener listener) {
        JButton button = new JButton(new ImageIcon(
                new ImageIcon(iconName).getImage().getScaledInstance(17, 17, java.awt.Image.SCALE_SMOOTH)));
        button.addActionListener(listener);
        button.setToolTipText(tipText);
        button.setPreferredSize(new Dimension(17, 17));
        return button;
    }

    public static JButton createNormalButton(String text, String tipText, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setToolTipText(tipText);
        return button;
    }

    public static JButton createInvisibleButton(String text, String tipText, ActionListener listener){
        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setToolTipText(tipText);
        button.setVisible(false);
        return button;
    }
}
