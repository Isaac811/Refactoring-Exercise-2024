
public class RetrieveLast implements RetrieveStrategy {
    @Override
    public void doRetrieve(EmployeeDetails employeeDetails) {
        // if any active record in file look for first record
        if (employeeDetails.isSomeoneToDisplay()) {
            // open file for reading
            employeeDetails.application.openReadFile(employeeDetails.file.getAbsolutePath());
            // get byte start in file for last record
            employeeDetails.currentByteStart = employeeDetails.application.getLast();
            // assign current Employee to first record in file
            employeeDetails.currentEmployee = employeeDetails.application.readRecords(employeeDetails.currentByteStart);
            employeeDetails.application.closeReadFile();// close file for reading
            // if last record is inactive look for previous record
            if (employeeDetails.currentEmployee.getEmployeeId() == 0)
                employeeDetails.previousRecord();// look for previous record
        } // end if
    }
}
