
public class RetrieveNext implements RetrieveStrategy {
    @Override
    public void doRetrieve(EmployeeDetails employeeDetails) {
        // if any active record in file look for first record
        if (employeeDetails.isSomeoneToDisplay()) {
            // open file for reading
            employeeDetails.application.openReadFile(employeeDetails.file.getAbsolutePath());
            // get byte start in file for next record
            employeeDetails.currentByteStart = employeeDetails.application.getNext(employeeDetails.currentByteStart);
            // assign current Employee to record in file
            employeeDetails.currentEmployee = employeeDetails.application.readRecords(employeeDetails.currentByteStart);
            // loop to previous next until Employee is active - ID is not 0
            while (employeeDetails.currentEmployee.getEmployeeId() == 0) {
                // get byte start in file for next record
                employeeDetails.currentByteStart = employeeDetails.application.getNext(employeeDetails.currentByteStart);
                // assign current Employee to next record in file
                employeeDetails.currentEmployee = employeeDetails.application.readRecords(employeeDetails.currentByteStart);
            } // end while
            employeeDetails.application.closeReadFile();// close file for reading
        } // end if
    }
}
