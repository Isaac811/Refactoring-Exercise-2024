
public interface RetrieveStrategy {

    void doRetrieve(EmployeeDetails employeeDetails);
}
