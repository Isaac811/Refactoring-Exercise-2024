
public class RetrievePrevious implements RetrieveStrategy {
    @Override
    public void doRetrieve(EmployeeDetails employeeDetails) {
        if (employeeDetails.isSomeoneToDisplay()) {
            // open file for reading
            employeeDetails.application.openReadFile(employeeDetails.file.getAbsolutePath());
            // get byte start in file for previous record
            employeeDetails.currentByteStart = employeeDetails.application.getPrevious(employeeDetails.currentByteStart);
            // assign current Employee to previous record in file
            employeeDetails.currentEmployee = employeeDetails.application.readRecords(employeeDetails.currentByteStart);
            // loop to previous record until Employee is active - ID is not 0
            while (employeeDetails.currentEmployee.getEmployeeId() == 0) {
                // get byte start in file for previous record
                employeeDetails.currentByteStart = employeeDetails.application.getPrevious(employeeDetails.currentByteStart);
                // assign current Employee to previous record in file
                employeeDetails.currentEmployee = employeeDetails.application.readRecords(employeeDetails.currentByteStart);
            } // end while
            employeeDetails.application.closeReadFile();// close file for reading
        }
    }
}
