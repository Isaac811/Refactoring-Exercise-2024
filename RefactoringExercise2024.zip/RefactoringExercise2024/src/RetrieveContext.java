
public class RetrieveContext {

    private RetrieveStrategy strategy;

    public RetrieveContext(RetrieveStrategy strategy){
        this.strategy = strategy;
    }

    public void retrieve(EmployeeDetails employeeDetails){
        this.strategy.doRetrieve(employeeDetails);
    }
}
