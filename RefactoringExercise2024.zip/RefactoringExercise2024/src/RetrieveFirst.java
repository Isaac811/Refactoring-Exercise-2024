
public class RetrieveFirst implements RetrieveStrategy {
    @Override
    public void doRetrieve(EmployeeDetails employeeDetails) {
        if (employeeDetails.isSomeoneToDisplay()) {
            // open file for reading
            employeeDetails.application.openReadFile(employeeDetails.file.getAbsolutePath());
            // get byte start in file for first record
            employeeDetails.currentByteStart = employeeDetails.application.getFirst();
            // assign current Employee to first record in file
            employeeDetails.currentEmployee = employeeDetails.application.readRecords(employeeDetails.currentByteStart);
            employeeDetails.application.closeReadFile();// close file for reading
            // if first record is inactive look for next record
            if (employeeDetails.currentEmployee.getEmployeeId() == 0)
                employeeDetails.nextRecord();// look for next record
        }
    }
}
