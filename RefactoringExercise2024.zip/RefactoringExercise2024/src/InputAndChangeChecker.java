import javax.swing.*;
import java.awt.*;

public class InputAndChangeChecker {

    public static boolean checkInputAndNoChanges(EmployeeDetails employeeDetails){
        return checkInput(employeeDetails) && !checkForChanges(employeeDetails);
    }

    public static boolean checkForChanges(EmployeeDetails employeeDetails){
        boolean anyChanges = false;
        // if changes where made, allow user to save there changes
        if (employeeDetails.change) {
            employeeDetails.saveChanges();// save changes
            anyChanges = true;
        } // end if
        // if no changes made, set text fields as unenabled and display
        // current Employee
        else {
            employeeDetails.setEnabled(false);
            employeeDetails.displayRecords(employeeDetails.currentEmployee);
        } // end else

        return anyChanges;
    }

    public static boolean checkInput(EmployeeDetails employeeDetails) {
        boolean valid = true;
        // if any of inputs are in wrong format, colour text field and display
        // message
        if (employeeDetails.ppsField.isEditable() && employeeDetails.ppsField.getText().trim().isEmpty()) {
            employeeDetails.ppsField.setBackground(new Color(255, 150, 150));
            valid = false;
        } // end if
        if (employeeDetails.ppsField.isEditable() && employeeDetails.correctPps(employeeDetails.ppsField.getText().trim(), employeeDetails.currentByteStart)) {
            employeeDetails.ppsField.setBackground(new Color(255, 150, 150));
            valid = false;
        } // end if
        if (employeeDetails.surnameField.isEditable() && employeeDetails.surnameField.getText().trim().isEmpty()) {
            employeeDetails.surnameField.setBackground(new Color(255, 150, 150));
            valid = false;
        } // end if
        if (employeeDetails.firstNameField.isEditable() && employeeDetails.firstNameField.getText().trim().isEmpty()) {
            employeeDetails.firstNameField.setBackground(new Color(255, 150, 150));
            valid = false;
        } // end if
        if (employeeDetails.genderCombo.getSelectedIndex() == 0 && employeeDetails.genderCombo.isEnabled()) {
            employeeDetails.genderCombo.setBackground(new Color(255, 150, 150));
            valid = false;
        } // end if
        if (employeeDetails.departmentCombo.getSelectedIndex() == 0 && employeeDetails.departmentCombo.isEnabled()) {
            employeeDetails.departmentCombo.setBackground(new Color(255, 150, 150));
            valid = false;
        } // end if
        try {// try to get values from text field
            Double.parseDouble(employeeDetails.salaryField.getText());
            // check if salary is greater than 0
            if (Double.parseDouble(employeeDetails.salaryField.getText()) < 0) {
                employeeDetails.salaryField.setBackground(new Color(255, 150, 150));
                valid = false;
            } // end if
        } // end try
        catch (NumberFormatException num) {
            if (employeeDetails.salaryField.isEditable()) {
                employeeDetails.salaryField.setBackground(new Color(255, 150, 150));
                valid = false;
            } // end if
        } // end catch
        if (employeeDetails.fullTimeCombo.getSelectedIndex() == 0 && employeeDetails.fullTimeCombo.isEnabled()) {
            employeeDetails.fullTimeCombo.setBackground(new Color(255, 150, 150));
            valid = false;
        } // end if
        // display message if any input or format is wrong
        if (!valid)
            JOptionPane.showMessageDialog(null, "Wrong values or format! Please check!");
        // set text field to white colour if text fields are editable
        if (employeeDetails.ppsField.isEditable())
            employeeDetails.setToWhite();

        return valid;
    }
}
